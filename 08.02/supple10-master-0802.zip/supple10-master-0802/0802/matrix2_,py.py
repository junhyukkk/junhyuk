
N = int(input())

arr = [list(map(int, input().split())) for _ in range(N)]

print(arr)

# 배열을 만드는데 1부터 10까지를 원소로 하는 배열을 만들자!!

lst = [i for i in range(1,11)]

print(lst)

"""
3
1 2 3
4 5 6
7 8 9
"""

# 행 우선 순회
for i in range(N):
    for j in range(N):
        print(arr[i][j], end=",")
    print()

print("=========================")
# 열 우선 순회
for j in range(N):
    for i in range(N):
        print(arr[i][j], end=",")
    print()