import sys

sys.stdin = open("sum_input.txt", "r")

T = 10

for tc in range(1, T + 1):
    # 테스트 케이스의 번호 입력 받기
    t = int(input())

    N = 100

    # 2차원 배열 입력 받기
    arr = [list(map(int, input().split())) for _ in range(N)]
    
    # 열의 합, 행의 합, 2개의 대각선의 합 중에서 가장 큰 값을 찾기
    max_value = 0


    # 행 우선 순회
    # i는 행 번호, j는 열번호
    for i in range(N):
        # 1
        sum = 0
        for j in range(N):
            # 현재위치 : (i,j) i행 j열
            # 2
            sum += arr[i][j]
        # 열 반복이 끝나면 한 행의 합이 구해진다.
        # 여기서 최대값 계산
        
        # 우리가 방금 구한 i행의 합 sum 이 max_value 보다 크면 갱신
        if max_value < sum:
            max_value = sum
 

    # 열 우선 순회
    # i는 행 번호, j는 열 번호
    for j in range(N):
        # 열의 합
        sum = 0
        for i in range(N):
            sum += arr[i][j]
        # 행 반복이 끝나면 열의 합이 구해진다.
        # 우리가 방금 구한 j열의 합이 내가 이전에 알고있던 최대값보다 크다면 갱신
        if sum > max_value:
            max_value = sum
    
    # 대각선 순회
    sum_down = 0
    sum_up = 0
    for i in range(N):
        # 오른쪽 아래로 가는 대각선 좌표 [i][i]
        sum_down += arr[i][i]
        # 오른쪽 위로 가는 대각선 좌표 [i][x]
        # i + x == N - 1
        # x == N - 1 - i
        # [i][N-1-i]
        sum_up += arr[i][N-1-i]

    if sum_down > max_value:
        max_value = sum_down

    if sum_up > max_value:
        max_value = sum_up

    print(f"#{tc} {max_value}")
