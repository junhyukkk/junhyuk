import sys

# 위에것이 대각선 합 판별 가능
sys.stdin = open("sum_input.txt" , "r")

# 익스퍼트 아카데미 입력파일은 대각선 합 판별 불가
# sys.stdin = open("input (2).txt", "r")


T = 10

for tc in range(1, T + 1):
    t = int(input())

    N = 100

    # 2차원 배열 입력 받기
    arr = [list(map(int, input().split())) for _ in range(N)]

    # 최대값 구하기
    max_value = 0

    # 오른쪽 아래로 가는 대각선의 합
    sum_down = 0
    # 오른쪽 위로 가는 대각선의 합
    sum_up = 0
    # 반복문 한덩어리로 끝내기
    for i in range(N):
        # 행의 합도 구하고
        sum_row = 0
        # 열의 합도 구하고
        sum_col = 0

        # 오른쪽 아래로 가는 대각선의 합
        sum_down += arr[i][i]

        # 오른쪽 위로가는 대각선의 합
        sum_up += arr[i][N-1-i]

        for j in range(N):
            sum_row += arr[i][j]  # i = 행 번호, j = 열 번호
            sum_col += arr[j][i]  # j = 행 번호, i = 열 번호

        # 행 / 열의 합이 구해지는 곳에서 값 비교
        if max_value < sum_row:
            max_value = sum_row
        if max_value < sum_col:
            max_value = sum_col

    # 대각선의 합
    if max_value < sum_down:
        max_value = sum_down
    if max_value < sum_up:
        max_value = sum_up

    # 최대값 출력
    print(f"#{tc} {max_value}")